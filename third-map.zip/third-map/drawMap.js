mapboxgl.accessToken = 'pk.eyJ1Ijoibm1hc3RyYWNjaSIsImEiOiJjamkwanM3ZTkxOHl1M2twZGtxbXlkbHVhIn0.8FA150ofp_Ai4ANsDpYlDg';

var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v10',
    center: [-79.21906, 43.12477],
    zoom: 15
});

map.on('load', function () {
    map.addLayer({
        "id": "Thorold",
        "type": "fill",
        "source": {
            "type": "geojson",
            "data": {
                "type": "Feature",
                "properties": {
                    "colour": "brown"
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [
                        [
                            [-79.22266960144043, 43.1244480399358],
                            [-79.22086715698242, 43.12209879603942],
                            [-79.21923637390137, 43.1227879169323],
                            [-79.21550273895262, 43.122913210806125],
                            [-79.21567440032959, 43.12696946134016],
                            [-79.22266960144043, 43.1244480399358]
                        ]
                    ]
                }
            }
        },
        "paint": {
            "fill-color": "#555",
            "fill-opacity": 0.5
        }
    });
});